// Burger Menu Toggle
const burger = document.querySelector('.burger');
const navLinks = document.querySelector('.nav-links');

burger.addEventListener('click', () => {
    navLinks.classList.toggle('nav-active');
    burger.classList.toggle('toggle');
});

// testimonials sliding effect

document.addEventListener("DOMContentLoaded", () => {
    const testimonialsWrapper = document.querySelector('.testimonials-wrapper');
    const testimonialsContainer = document.querySelector('.testimonials-container');
    const testimonials = document.querySelectorAll('.testimonial');
    const testimonialWidth = testimonials[0].offsetWidth + 20; // 20 is the margin-right
    const totalWidth = testimonialWidth * testimonials.length;
    let scrollPosition = 0;

    function scrollTestimonials() {
        scrollPosition += 1;
        if (scrollPosition >= totalWidth) {
            scrollPosition = 0;
        }
        testimonialsWrapper.style.transform = `translateX(-${scrollPosition}px)`;
        requestAnimationFrame(scrollTestimonials);
    }

    // Clone the testimonials to ensure seamless looping
    testimonialsWrapper.innerHTML += testimonialsWrapper.innerHTML;

    testimonialsWrapper.style.width = `${totalWidth * 2}px`; // Double the width to accommodate cloned testimonials

    requestAnimationFrame(scrollTestimonials);
});
