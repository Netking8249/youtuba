document.addEventListener("DOMContentLoaded", function() {
    const captchaElement = document.getElementById('captcha');
    const captchaInput = document.getElementById('captcha-input');
    const registerForm = document.getElementById('register-form');
    const refreshCaptchaBtn = document.getElementById('refresh-captcha');

    // Function to generate a random captcha math problem
    function generateCaptcha() {
        const num1 = Math.floor(Math.random() * 10);
        const num2 = Math.floor(Math.random() * 10);
        captchaElement.textContent = `${num1} + ${num2} = ?`;
        return num1 + num2;
    }

    let captchaSolution = generateCaptcha();

    refreshCaptchaBtn.addEventListener('click', function() {
        captchaSolution = generateCaptcha();
        captchaInput.value = '';
    });

    registerForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const userCaptcha = parseInt(captchaInput.value, 10);

        if (userCaptcha === captchaSolution) {
            alert("Captcha verified successfully. Form submitted.");
            // Here you can add code to handle form submission, e.g., sending data to the server
        } else {
            alert("Incorrect captcha. Please try again.");
            captchaSolution = generateCaptcha();
            captchaInput.value = '';
        }
    });
});
